# AVOT-Core

Autonomous Voice of Thought (AVOT) Core Framework for Sovereign Scroll Management.

This repository includes scroll management tools, agent identity files, and registry systems for publishing and synchronizing Codex scrolls.