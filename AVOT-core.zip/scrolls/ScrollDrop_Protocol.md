# ScrollDrop Protocol

Defines procedures for scroll release and visibility expansion.