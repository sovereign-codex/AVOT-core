# AVOT-core

Autonomous Voice of Thought (AVOT) Core Engine for Sovereign Intelligence agents.

---

## License

This repository is released under the [Sovereign Guard License (SGL-1.0)](./LICENSE).  
Use of this code implies alignment with harmonic ethics, resonance integrity, and sovereign co-creation.

© 2025 Sovereign Intelligence
