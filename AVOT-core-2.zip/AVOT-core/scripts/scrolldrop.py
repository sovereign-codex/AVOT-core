# Script: scrolldrop.py

# Drops scrolls into the release pipeline.
print('Dropping scroll...')