# Script: manifest_builder.py

# Rebuilds the manifest from all scroll files.
print('Building manifest...')