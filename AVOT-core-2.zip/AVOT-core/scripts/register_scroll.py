# Script: register_scroll.py

# Registers a new scroll into the manifest.
print('Registering scroll...')