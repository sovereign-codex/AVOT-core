# AVOT Activation Ritual

A ritual scroll for initializing AVOT nodes.