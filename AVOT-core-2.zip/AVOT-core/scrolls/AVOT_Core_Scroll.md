# AVOT Core Scroll

This is the foundational scroll for the AVOT system.